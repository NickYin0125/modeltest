# DISCOVER — Observe one bounded area

## Input

The task, current inventory slice, relevant navigation edges, current page dossier, and optional Recorder/Codegen evidence.

## Actions

First map accessible navigation shallowly, one menu branch or similarly small area at a time. For a selected capability group, inspect only the states required for its contract. Build useful implementations while later discovery remains queued; do not perform an exhaustive deep crawl first.

Record stable page IDs, navigation path, page-state fingerprint, dialogs/tabs/drawers, iframe boundaries, permission/data preconditions, visible controls, and observed capabilities. Identify whether a table uses ordinary DOM, virtualized DOM, Canvas, or a mixture. A visible viewport does not prove full dataset coverage.

Use small CLI queries or relevant snapshot sections. Optional recordings provide candidates, not proof of current correctness. Verify candidate uniqueness and intended scope. Where a dropdown is dynamic, capture its dependency and sampling conditions rather than treating current choices as a permanent enumeration.

Use CDP only for a specific gap such as geometry, frame identity, console failure, or a targeted network/runtime question. Inspect the same intended target or explicitly separate evidence by run. Do not use JavaScript state mutation or API writes as a substitute for exercising the UI.

Maintain read-only application access. Do not click an unknown action to discover whether it is destructive. Record inaccessible/unvisited controls and the reason rather than bypassing permissions.

## Output and exit gate

Update inventory identities/capability candidates, observed navigation edges, a concise page dossier, and relevant evidence references. Mark incomplete observations explicitly. The next MODEL task must name a bounded capability group and its unresolved questions.

Canvas evidence belongs in the relevant `canvas_probe.json` only when needed. Include CSS viewport geometry, buffer dimensions, scale/zoom, scroll/frozen regions when observable, state/build provenance, tested hypotheses, and failures. Never call a coordinate recipe universal based on one click.
