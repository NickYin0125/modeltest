# MODEL — Define the implementable contract

## Input

Observed page dossier, relevant evidence, current Ruby classes, and applicable sample conventions.

## Actions

For each capability in the unit, define its entry UI state, required role/data, intended user action, input fields/types, expected return value, UI readiness condition, deterministic observable postcondition, and risk/authorization boundary.

Map fields and actions to logical locator keys and proposed Ruby method names. Confirm control type: native select and custom combobox need different interaction contracts. Account for frame boundaries, duplicate labels, tabs, virtualized rows, pagination, and required dependencies only where actually observed.

For DOM tables, prefer a business row key and identified column semantics over a fixed row/column index. State explicitly whether a read method returns visible rows, a page, or all records; do not silently promise full-dataset reads.

Separate page navigation, field entry, save/cancel, result reading, and business assertions where useful. Readiness guards may live in the Page Object; business test oracles belong outside it. Do not hide settlement/business side effects in generic navigation helpers.

Reuse existing components. Introduce a new shared component only when at least two observed uses justify the abstraction; otherwise keep a local helper. Record material deviations from existing conventions instead of redesigning the library.

## Output and exit gate

Add a compact contract to the page dossier: proposed methods/signatures, state transitions, field/control mappings, preconditions, observable postconditions, verification plan, and evidence pointers.

Known evidence is required for executable behavior. An unresolved input, locator, or postcondition stays an explicit gap; return to focused discovery rather than inventing it. Existing mature contracts need not be rewritten. Queue the smallest IMPLEMENT unit with exact files and methods in scope.
