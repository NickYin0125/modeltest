# BASELINE — Inspect and calibrate

## Input

Applicable instructions, current Git status, README, dependency lock/configuration, existing runtime/loader, foundation pages, two sample business pages, existing inventory and navigation artifacts.

## Actions

Inspect actual files rather than inferring content from their names. Determine namespace, constructors, browser ownership, locator patterns, navigation style, public method conventions, wait/error behavior, and existing smoke/example conventions.

Record exact installed Ruby, gem, driver, browser, and browser-tool versions where locally available. Do not assume the CLI's JavaScript runtime and Ruby's driver are the same dependency. Do not upgrade either to resolve an uninvestigated mismatch.

Identify the approved environment, current role scope, credentials source reference without reading secrets into output, and mutation authorization. Unknown values remain null. Inspect local help or installed skills only where necessary.

Run syntax/load checks for the relevant existing code where safe. Before a load check, inspect initialization for browser launches or other side effects. Live read-only checks are optional when browser access is ready; unavailable browser access need not prevent file inspection.

## Output and exit gate

Create/update `docs/engineering_baseline.md` with concise observed conventions, sample references, version facts, usable commands, restrictions, and gaps. Map the existing business pages into inventory with truthful per-capability verification states. Do not assume a sample is correct because it exists.

Create missing operational artifacts only. Preserve equivalent artifacts already in use and document path/schema decisions. Baseline ends with a precise, bounded discovery task. No global architecture rewrite or regenerated sample pages.
