# IMPLEMENT — Make the smallest compatible Ruby change

## Input

A sufficiently evidenced capability contract, current Page Object and foundation classes, relevant samples, and installed Ruby API information.

## Actions

Preserve the existing module/loader/runtime design and public API unless a specific change is justified. Add only methods needed by the selected capability group. Do not introduce an additional browser runtime just because discovery used a different tool.

Use actual `playwright-ruby-client` signatures, not a mechanical translation of JavaScript Codegen. Verify questionable APIs locally. Do not upgrade dependencies as a shortcut.

Centralize executable locators in the Ruby implementation. Prefer scoped role/label/test-ID patterns or stable CSS supported by observed markup. Do not persist CLI `eNN` refs, CDP node IDs, or transient element handles as durable selectors. Do not mask strictness failures with arbitrary first/nth selections.

Keep helpers small and explicit. No arbitrary sleeps, blanket rescue returning success, synthetic JavaScript clicks as an unreported fallback, or bypassing the UI through backend writes. Expose clear errors when required controls or data are missing.

For reusable components, update only the necessary shared code and identify existing callers to reverify. Do not migrate all pages during one capability task.

Use an existing smoke/example mechanism or a small standalone Ruby script for method-level verification. No new framework or business scenarios.

## Output and exit gate

Save the focused code diff, update the capability-to-method mapping, and run safe syntax/load checks. Record unavailable checks. Implementation status means code exists, not that the capability works.

Mark affected old verification stale and queue VERIFY with the exact Ruby methods, expected observations, test-data requirements, and reproducible invocation. Do not claim success based on CLI replay alone.
