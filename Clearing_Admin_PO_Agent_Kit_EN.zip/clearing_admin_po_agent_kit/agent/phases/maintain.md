# MAINTAIN — Repair scoped drift

## Input

A reported failure, changed build/role/environment, code diff, changed UI evidence, or an explicitly requested scoped health check.

## Actions

Reproduce one selected failure safely and check the environment first. Distinguish selector drift from expired authentication, authorization, absent test data, application behavior, browser/tool configuration, and Ruby implementation defects.

Read the current contract and last applicable evidence. Do not rediscover the whole application. When a contract or locator has changed, mark affected verification stale while retaining its historical evidence. Unchanged unrelated capabilities need not be invalidated without reason.

Repair the smallest affected area through DISCOVER/MODEL/IMPLEMENT as needed. A changed shared component requires a caller/dependency impact check and targeted revalidation, including existing sample pages where affected.

Preserve public method contracts unless the UI change requires a documented incompatibility. Do not add silent selector fallbacks, catch exceptions as success, or revise assertions just to make a failure disappear.

An inaccessible control is not automatically deleted. Record access/build scope and mark removal as unconfirmed until evidence supports it. Do not bypass permissions to resolve the question.

## Output and exit gate

Update current facts, navigation deltas where relevant, code, capability verification, and a brief regression record. Keep historical failure evidence locally with sanitized references. Explain changed contracts and remaining blockers.

Do not label a capability verified until actual Ruby validation and relevant repeatability checks pass again. Checkpoint the next task or a concrete human unblock request. Maintenance runs occur on invocation; this file does not establish a background schedule.
