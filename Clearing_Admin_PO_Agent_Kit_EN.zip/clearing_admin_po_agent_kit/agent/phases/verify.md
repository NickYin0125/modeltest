# VERIFY — Prove the actual implementation

## Input

Current Ruby code and fingerprint, capability contract, relevant environment/role/build scope, a safe starting state, and any task-scoped write authorization.

## Verification layers

1. **Static:** syntax and safe load checks for the changed code and affected loader/runtime. Static checks do not establish live UI correctness.
2. **Browser:** demonstrate that the observed locator/action reaches the intended control and produces the contract's observable state. Tool-level success is not a Ruby execution result.
3. **Ruby execution:** run the actual implemented methods through the existing Ruby runtime. Use deterministic assertions. Do not replace them with a separate JavaScript replay and report that as Ruby verification.
4. **Repeatability:** restore or reconstruct the entry state and repeat the representative Ruby interaction. Include a relevant locator stressor where justified, such as another business key, pagination, or duplicate-label scoping. Two repeats are a smoke confidence check, not proof against all UI changes.

For read capabilities, verify expected identity/value/state, not merely the absence of an exception. For authorized writes, verify persisted results through the UI after a fresh read when feasible; a success toast alone may be insufficient. Do not execute writes without approval just to fill a coverage gap.

Use only authorized disposable test data, a persisted write intent, and a documented cleanup plan. If an outcome is uncertain, inspect it before retrying. Escalate unresolved cleanup instead of silently abandoning it.

## Record and exit gate

Store the actual commands, exit codes, assertions/observations, timestamp, code fingerprint, environment/role/build scope when known, and sanitized evidence pointers. Keep `not_run`, `pass`, `fail`, `blocked`, and `stale` distinct for each layer.

A capability may reach `verified` only when its required layers pass for the current code and scope, including Ruby execution and the defined repeatability check. Restricted layers remain blocked/unverified. Do not declare a whole page complete while required capabilities remain unverified.

Update inventory and dossier, restore a safe UI state, record pending cleanup, and checkpoint. Route defects to the smallest corrective phase; do not erase failed evidence or weaken the oracle.
