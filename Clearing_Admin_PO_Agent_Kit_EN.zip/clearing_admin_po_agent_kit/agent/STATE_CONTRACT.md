# Persistent State Contract

These structures are small working records, not a second automation framework. Preserve existing compatible schemas. Document necessary additive changes and keep stable IDs.

## Artifact ownership

- **Ruby source:** executable locators, components, and public method implementations.
- **`page_inventory.json`:** canonical page/capability identity, dependency and coverage metadata, implementation references, current verification summaries. Read entries selectively with a local JSON query, not full-file dumps.
- **`navigation_graph.md`:** observed edges between page/UI states. Include entry action, precondition, observation scope, and evidence reference. Do not duplicate all locators or task statuses here.
- **`exploration_state.json`:** scheduler cursor and recovery state. Queue entries reference page/capability IDs; they do not duplicate canonical verification results.
- **`docs/pages/<page_id>.md`:** concise current contract and findings, including evidence gaps. It is not an append-only transcript.
- **`evidence/<page_id>/`:** raw/normalized evidence and run reports, selectively retained and sanitized. Only approved safe evidence should be committed. Auth/profile data stays outside Git. Create Canvas probes only for real Canvas work.

## Inventory minimum

At the top level retain `schema_version`, a coverage scope (environment, role label, app build and business date when relevant), and `pages`.

Each page needs a stable ID, observed label/navigation identity, implementation path/class if present, dossier path, and capability records. Each capability needs:

- stable `id`, concise intent, and `required` status (`null` means scope not decided);
- state fingerprint/preconditions, data dependencies, and action risk;
- `stage`: `discovered`, `modeled`, `implemented`, `verified`, `blocked`, `stale`, or `deferred`;
- last completed stage when blocked, reason, and a concrete unblock condition;
- Ruby method references and evidence pointers;
- independent `static`, `browser`, `ruby`, and `repeatability` verification records.

Each verification record uses `not_run`, `pass`, `fail`, `blocked`, or `stale`, plus its report pointer, timestamp, code fingerprint and applicable environment/build scope. Required layers are stated in the capability contract. Reconcile equivalent existing fields instead of duplicating them.

Keep page readiness derived from capabilities. Do not hand-maintain a conflicting page-level `done` flag. A fully ready page has current verification for all required in-scope capabilities. A safe subset may be described as `ready_for_read_only_use`, with unverified writes explicitly excluded. Do not remove blockers from the denominator to improve coverage.

Report known capability totals separately from unknown/unvisited page areas. No claim of whole-system coverage without a confirmed inventory boundary or an explicit limitation to observed navigation and permissions.

## Cursor minimum

Store `schema_version`, a checkpoint ID/revision, phase/mode, run status, budgets, authorization policy, one active task, queue references, observed browser identity, and recovery information.

An active task contains task ID, page ID, capability IDs, phase, one exact next action, preconditions, relevant file/evidence pointers, failed hypotheses, and blocker/unblock condition if present. Its next action should be executable, for example: "Run the existing Ruby smoke command for method X and assert the filtered row key", not "continue testing".

A normal resume prefers an unfinished eligible active task. Otherwise select an explicitly requested target, then the highest-priority dependency-ready queue entry with sufficient authorization. Do not repeatedly select blocked work until its unblock condition has changed. Preserve the queue order when priorities are equal.

## Crash-safe checkpoints and application writes

Write a small checkpoint after each phase, verified finding, and at least five meaningful browser calls. Never wait for a guessed context-percentage threshold.

For file changes: save source and evidence; update inventory and current page notes; validate JSON, IDs, and references; write the cursor last. Atomic replacement protects each file, not the entire multi-file transaction. On resume, compare recorded code fingerprints and current diffs; reconcile partially written checkpoints before continuing. Do not automatically stash, revert, commit, or push user work.

For an authorized application mutation: persist the target environment, approved operation, disposable test-data identifier, intended effect, observation query, and cleanup plan before clicking. Update its outcome as `confirmed`, `not_applied`, or `unknown` afterward. A timeout or tool failure can leave outcome unknown. Read the actual UI/backend-observable state through approved read paths before any retry; do not assume failure means no write occurred.

Keep cleanup debt visible until resolved or explicitly handed back. Do not encode production account data, tokens, secrets, or full auth state in the cursor. Store only approved local references.

## Context loading

Always-loaded instructions should remain short. Load one phase guide and one page dossier for the current task. Archive old raw details and retain a compact current summary of facts and rejected hypotheses. Do not automatically load every guide or all historical evidence after compaction.

Context reset is recoverable only to the extent the checkpoint is accurate. Abrupt failures can still lose unpersisted work. A saved browser profile is not a substitute for cursor/code/evidence checks, and this protocol cannot guarantee zero context consumption or zero lost work.
