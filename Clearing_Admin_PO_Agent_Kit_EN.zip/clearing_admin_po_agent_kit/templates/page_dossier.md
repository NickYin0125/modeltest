# <Observed Page Label>

Page ID: <stable identifier>
Status: template; no observations verified.

## Scope and entry

Environment/role/build, navigation path, UI-state fingerprint, relevant frames, and data preconditions. Unknowns remain explicit.

## Observed capabilities and states

Only observed actions and their dialogs/tabs/modes. Identify capabilities still awaiting discovery.

## Current capability contract

Method/API intent, entry state, inputs/control types, return value, state transition, readiness condition, observable postcondition, and action risk. Separate observed facts from hypotheses.

## Implementation and locators

Reference Ruby files/classes/methods and logical locator identities. Do not create a duplicate executable locator registry or persist temporary snapshot references.

## Evidence and verification

Targeted evidence/report references. Static, browser, Ruby execution, and repeatability statuses are recorded separately in the canonical inventory.

## Gaps and rejected hypotheses

Concise unresolved questions, tried approaches and why they failed, and concrete unblock conditions. No full conversation transcript.
