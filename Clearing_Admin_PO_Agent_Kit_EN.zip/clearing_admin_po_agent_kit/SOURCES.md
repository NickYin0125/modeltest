# Official References

Checked on 2026-10-13. These references support tool capabilities, not claims about the company's actual repository or environment. The local installed versions and help remain the execution contract. Phase structure, work budgets, statuses, and artifact design are project proposals, not vendor defaults.

- OpenAI, project instructions with AGENTS.md: https://developers.openai.com/codex/guides/agents-md
- OpenCode V2, instructions: https://opencode.ai/v2/docs/instructions/
- OpenCode V2, compaction and its limitations: https://opencode.ai/v2/docs/compaction/
- Microsoft, Playwright CLI introduction and output model: https://playwright.dev/agent-cli/introduction
- Microsoft, Playwright CLI session behavior: https://playwright.dev/agent-cli/sessions
- Microsoft, Playwright CLI attachment modes: https://playwright.dev/agent-cli/commands/attach
- Microsoft, Playwright locator guidance: https://playwright.dev/docs/locators
- Microsoft, Page Object guidance: https://playwright.dev/docs/pom
- Google, Chrome DevTools MCP and privacy/diagnostic capabilities: https://github.com/ChromeDevTools/chrome-devtools-mcp

Not every latest CLI flag is available on a pinned corporate installation. This kit intentionally avoids requiring new attachment flags or optional MCP features without local capability checks.
