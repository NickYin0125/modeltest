# Run Prompts

These are ordinary English messages, not native slash commands. Send them after the project protocol has been bootstrapped. Preserve any supplied task-specific authorization limits.

## Normal continuation

```text
Continue the Clearing Admin Page Object engineering workflow.
Read the applicable AGENTS.md and exploration_state.json first.
Resume the next eligible capability-level task; do not restart discovery.
Load only its page context and the active phase guide.
Complete at most one bounded work unit under the saved safety policy and budgets.
Checkpoint the evidence, implementation/verification status, and exact next action.
```

## Discover a selected area

```text
Run DISCOVER for the next unvisited navigation area in the saved queue.
Use read-only exploration and Playwright CLI. Use CDP only for a named evidence gap.
Map one bounded menu area, or deeply inspect one selected capability group, not both exhaustively.
Update observed navigation, inventory, and the active page dossier. Do not generate Ruby code yet.
Checkpoint a specific MODEL task and stop at the saved budget.
```

## Model before coding

```text
Run MODEL for the active discovered capability group.
Use the current evidence and existing Ruby samples to define its public API,
preconditions, input/control mapping, return values, and observable postconditions.
Resolve only essential evidence gaps. Do not invent behavior or edit production Page Objects yet.
Checkpoint the smallest implementation task.
```

## Implement a ready contract

```text
Run IMPLEMENT for the next modeled, dependency-ready capability group.
Read its contract and the relevant existing Ruby code, not the entire repository.
Make the smallest compatible change. Run safe syntax/load checks.
Do not equate code generation with browser or Ruby verification.
Queue the exact VERIFY action and checkpoint.
```

## Verify the actual Ruby methods

```text
Run VERIFY for the next implemented capability group.
Execute the actual Ruby Page Object methods through the existing runtime.
Use deterministic postconditions and repeat from a reconstructed entry state.
Keep static checks, browser evidence, Ruby execution, and repeatability results separate.
Do not perform unauthorized application writes. Record blocked checks honestly.
Update capability readiness and checkpoint.
```

## Maintain a reported regression

```text
Run MAINTAIN for the reported failing capability, or the next stale eligible capability in the queue.
Classify environment/login/data/application/tooling/locator/Ruby causes before changing code.
Use focused evidence, repair only the affected contract or implementation,
and verify affected callers of any shared component changed.
Retain failed evidence and do not weaken assertions to obtain a pass.
Checkpoint the result and remaining gaps.
```

## Recover after compaction or a new session

```text
Recover this project from repository artifacts, not from a reconstructed conversation.
Read the applicable AGENTS.md, exploration_state.json, and the active page context.
Reconcile the saved cursor with the current Git diff, code fingerprint, and browser state.
Inspect any pending write outcome before retrying; never repeat an uncertain mutation blindly.
Resume the exact next eligible action and complete one bounded unit.
```

## Scope an explicitly authorized test-data write

Do not use this message until real values and approval are available. Placeholders are not authorization.

```text
For the named capability only, authorize the following test-environment write verification:
Environment/origin: <approved environment>
Capability and permitted operations: <exact scope>
Disposable test-data identifier or prefix: <approved identifier>
Allowed references/dependencies: <approved references>
Cleanup procedure and scope: <approved cleanup>
No other application writes are authorized.
Persist a write intent, execute once, verify the observable outcome,
and reconcile uncertain outcomes before any retry. Report unresolved cleanup.
```
