# Clearing Admin Page Object Agent Kit

Purpose: evolve an existing Ruby Page Object library through bounded, resumable, evidence-driven work. This is not an installer, a test framework, or an autonomous background service.

## Apply safely

1. Extract this kit into a staging directory, not directly over the existing repository.
2. Start the coding agent in the actual `clearing_admin_page_objects` project directory. Supply `BOOTSTRAP_PROMPT.md` and the staged kit location.
3. The agent must inspect existing instructions and files, merge compatible guidance, and preserve user changes. `AGENTS.proposed.md` is a proposal, not an instruction to overwrite an existing `AGENTS.md`.
4. Copy phase guides and the state contract into the project's `agent/` directory only after checking for existing equivalents. Adapt paths rather than creating duplicate sources of truth.
5. Templates are UNINITIALIZED. Empty lists and null values mean unknown or not started. They are not evidence of successful discovery or verification.
6. Start with BASELINE and a bounded, read-only DISCOVER unit. Use `RUN_PROMPTS.md` for later sessions.

Only a short project `AGENTS.md` should load routinely. The active phase guide and active page dossier are loaded on demand. Do not put this entire kit into every model request.

## Contents

- `BOOTSTRAP_PROMPT.md`: first-run implementation instruction.
- `AGENTS.proposed.md`: compact, persistent working rules.
- `agent/phases/`: six on-demand phase guides.
- `agent/STATE_CONTRACT.md`: artifact ownership, status semantics, and crash recovery.
- `RUN_PROMPTS.md`: normal-language task prompts; these are not built-in slash commands.
- `templates/`: empty inventory/state/navigation and page-dossier templates.
- `SOURCES.md`: official references supporting tool-related decisions.

The kit author has not read or modified the company repository and has not executed its Ruby/browser checks. The local agent must verify those facts in the target environment.
